<script type="text/javascript">
    function check_pm_fk(){
        document.getElementById('payment_form').submit();
    }
</script>
